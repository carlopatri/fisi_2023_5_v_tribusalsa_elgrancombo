const direccionesController = require('../controllers/direccionesController');
const passport = require('passport');

module.exports = (app) => {
    app.post('/api/direcciones/create', passport.authenticate('jwt', {session: false}), 
        direccionesController.create);
}