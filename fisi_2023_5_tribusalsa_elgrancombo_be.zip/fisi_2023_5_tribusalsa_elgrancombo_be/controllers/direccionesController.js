const Direccion = require('../models/direccion');

module.exports = {
    create (req, res){
        const direccion = req.body;

        Direccion.create(direccion, (err, id) => {
            if(err){
                return res.status(501).json({
                    success: false,
                    message: 'Hubo un error con el registro de la dirección',
                    error: err
                });
            }

            return res.status(201).json({
                success: true,
                message: 'La dirección se creó correctamente',
                data: `${id}`
            });
        });
    }
}