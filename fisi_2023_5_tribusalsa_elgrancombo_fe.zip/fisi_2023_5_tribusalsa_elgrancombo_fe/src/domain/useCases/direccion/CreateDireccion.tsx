import { DireccionRepositoryImpl } from "../../../data/repositories/DireccionRepository";
import { Direccion } from "../../entities/Direccion";

const { create } = new DireccionRepositoryImpl();

export const CreateDireccionUseCase = async(direccion: Direccion ) => {
    return await create(direccion);
}