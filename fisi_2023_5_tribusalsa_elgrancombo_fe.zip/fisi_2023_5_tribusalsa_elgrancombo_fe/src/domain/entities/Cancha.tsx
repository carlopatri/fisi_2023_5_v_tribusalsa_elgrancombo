export interface Cancha {
    id?: string;
    name: string;
    category: string;
    size: string;
    price_per_hour: string;
    images: string;
    image: string
}