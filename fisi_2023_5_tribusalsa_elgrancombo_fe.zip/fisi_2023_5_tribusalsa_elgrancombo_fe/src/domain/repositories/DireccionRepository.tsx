import { ResponseFisiFutApp } from "../../data/sources/remote/models/ResponseFisiFutApp";
import { Direccion } from "../entities/Direccion";

export interface DireccionRepository {
    create(direccion: Direccion): Promise<ResponseFisiFutApp>;
}