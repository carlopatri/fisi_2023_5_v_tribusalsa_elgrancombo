import React from 'react'
import { Text, View } from 'react-native'

export const CanchaAddressListScreen = () => {
    return (
        <View>
            <Text>
                CanchaAddressListScreen
            </Text>
        </View>
    )
}