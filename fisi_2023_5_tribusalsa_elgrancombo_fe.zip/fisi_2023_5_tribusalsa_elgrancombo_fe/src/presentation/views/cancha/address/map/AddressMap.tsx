import React, { useEffect } from 'react';
import { Text, View, ToastAndroid, Image } from 'react-native';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps'; 
import { RoundedButton } from '../../../../components/RoundedButton';
import styles from './Styles';
import useViewModel from './ViewModel';
import { StackScreenProps } from '@react-navigation/stack';
import { CanchaStackParamList } from '../../../../navigator/CanchaCategoryNavigator';

interface Props extends StackScreenProps<CanchaStackParamList, 'CanchaAddressMapScreen'>{};

export const CanchaAddressMapScreen = ({ navigation, route }: Props) => {
    const { messagePermisions, position, mapRef, 
        name, latitude, longitude, onRegionChangeComplete } = useViewModel();
    
    useEffect(() => {
        if (messagePermisions != ''){
            ToastAndroid.show(messagePermisions, ToastAndroid.LONG);
        }
    }, [messagePermisions])

    return(
        <View style = {styles.container }> 
            <MapView
                ref = { mapRef }
                style = {{ height: '100%', width: '100%' }}
                provider = { PROVIDER_GOOGLE }
                onRegionChangeComplete = { (region) => {
                    onRegionChangeComplete(region.latitude, region.longitude);
                }}
            />

            <Image 
                style = { styles.imageLocation }
                source = {require('../../../../../../assets/location_home.png')}
            />

            <View style = { styles.refPoint }>
                <Text style = { styles.refPointText }>{ name }</Text>
            </View>

            <View style = { styles.buttonRefPoint }>
                <RoundedButton
                    text='Seleccionar punto de referencia'
                    onPress={() => {
                        navigation.navigate({
                            name: 'CanchaAddressCreateScreen',
                            merge: true,
                            params: {
                                refPoint: name,
                                latitude: latitude,
                                longitude: longitude
                            }
                        })
                    }}
                />
            </View>
        </View>
    )
}