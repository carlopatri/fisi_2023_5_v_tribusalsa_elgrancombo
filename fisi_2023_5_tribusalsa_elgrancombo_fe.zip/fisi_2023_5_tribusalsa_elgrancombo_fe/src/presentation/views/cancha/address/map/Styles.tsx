import { StyleSheet } from "react-native";
import { MyColors } from "../../../../theme/AppTheme";

const CanchaAdressMapStyles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: MyColors.defaultText,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imageLocation: {
        height: 65,
        width: 65,
        justifyContent: 'center',
        position: 'absolute'
    },
    refPoint: {
        position: 'absolute',
        backgroundColor: MyColors.quaternary,
        width: '70%',
        paddingVertical: 4,
        top: 40,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    refPointText: {
        textAlign: 'center'
    },
    buttonRefPoint: {
        position: 'absolute',
        bottom: 60,
        width: '85%'
    }
});

export default CanchaAdressMapStyles;