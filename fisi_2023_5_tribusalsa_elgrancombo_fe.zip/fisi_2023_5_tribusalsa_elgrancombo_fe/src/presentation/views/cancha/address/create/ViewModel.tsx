import { useContext, useState, useEffect } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { CreateCanchaUseCase } from '../../../../../domain/useCases/cancha/CreateCancha';
import { ClienteContext } from '../../../../context/ClienteContext';
import { CanchaContext } from '../../../../context/CanchaContext';
import { CreateDireccionUseCase } from '../../../../../domain/useCases/direccion/CreateDireccion';

const CanchaAddressCreateViewModel = () => {
    const [values, setValues] = useState({
        address: '',
        district: '',
        refPoint: '',
        lat: 0.0,
        lng: 0.0,
        id_cancha: ''
    });

    const [responseMessage, setResponseMessage] = useState('');
    const [loading, setLoading] = useState(false)
    const [file, setFile] = useState<ImagePicker.ImagePickerAsset>() //Igual a ImageInfo
    const { create, canchas } = useContext(CanchaContext);
    const { cliente } = useContext(ClienteContext);

    useEffect(() => {
        
    }, [])

    const onChange = (property: string, value: any) => {
        setValues({...values, [property]: value});
    }

    const createDireccion = async (clienteId: string) => {
      setLoading(true);
      const response = await create({ ...values, id_gestor: clienteId } as any, file!);
      setLoading(false);
      setResponseMessage(response.message);
      resetForm();
    } 

    const resetForm = async () => {

    }

    return {
        ...values,
        onChange,
        createDireccion,
        cliente,
        loading,
        responseMessage
    }
}

export default CanchaAddressCreateViewModel;