import React from 'react'
import { Text, View } from 'react-native'

export const ClienteAlquilerListScreen = () => {
    return (
        <View>
            <Text>
                ClienteAlquilerListScreen
            </Text>
        </View>
    )
}