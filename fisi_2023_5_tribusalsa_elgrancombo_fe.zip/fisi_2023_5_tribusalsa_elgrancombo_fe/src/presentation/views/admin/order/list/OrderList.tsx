import React from 'react'
import { Text, View } from 'react-native'

export const AdminGananciasListScreen = () => {
    return (
        <View>
            <Text>
                AdminGananciasListScreen
            </Text>
        </View>
    )
}