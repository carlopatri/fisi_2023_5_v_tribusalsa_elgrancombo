import React from 'react'
import { Text, View } from 'react-native'

export const AdminCanchasListScreen = () => {
    return (
        <View>
            <Text>
                AdminCanchasListScreen
            </Text>
        </View>
    )
}