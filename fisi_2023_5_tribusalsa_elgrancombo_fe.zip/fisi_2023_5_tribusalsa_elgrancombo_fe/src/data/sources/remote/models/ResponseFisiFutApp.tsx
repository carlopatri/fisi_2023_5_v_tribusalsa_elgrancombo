export interface ResponseFisiFutApp {
    success: boolean;
    message: string;
    data?:    any;
    error?:  any;
}